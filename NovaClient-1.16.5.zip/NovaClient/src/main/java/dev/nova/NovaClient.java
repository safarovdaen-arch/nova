package dev.nova;

import dev.nova.gui.ClickGuiScreen;
import dev.nova.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public class NovaClient implements ClientModInitializer {
    public static final int MENU_KEY = GLFW.GLFW_KEY_RIGHT_SHIFT;
    private static boolean menuKeyWasDown;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
    }

    /** Вызывается из MinecraftClientMixin в конце каждого тика. */
    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;

        if (Commands.openMenuNextTick && mc.currentScreen == null) {
            Commands.openMenuNextTick = false;
            mc.openScreen(new ClickGuiScreen());
        }

        boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), MENU_KEY) == GLFW.GLFW_PRESS;
        if (down && !menuKeyWasDown && mc.currentScreen == null) {
            mc.openScreen(new ClickGuiScreen());
        }
        menuKeyWasDown = down;

        ModuleManager.onTick(mc);
    }
}

package dev.nova.setting;

public class NumberSetting extends Setting {
    private float value;
    private final float min, max;
    public NumberSetting(String name, float def, float min, float max) {
        super(name);
        this.value = def;
        this.min = min;
        this.max = max;
    }
    public float get() { return value; }
    public void set(float v) { value = Math.max(min, Math.min(max, v)); }
    public float getMin() { return min; }
    public float getMax() { return max; }
}

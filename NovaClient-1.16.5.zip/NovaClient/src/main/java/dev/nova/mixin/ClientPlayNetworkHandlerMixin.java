package dev.nova.mixin;

import dev.nova.module.ModuleManager;
import dev.nova.module.impl.Velocity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onVelocityUpdate", at = @At("HEAD"), cancellable = true)
    private void nova$velocity(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        Velocity mod = ModuleManager.get(Velocity.class);
        if (mod != null && mod.isEnabled() && packet.getId() == mc.player.getEntityId()) {
            ci.cancel();
        }
    }
}

package dev.nova;

import dev.nova.module.Module;
import dev.nova.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.LiteralText;

/** Команды в чате: .menu  .t <модуль>  .help — чтобы можно было играть с телефона без клавиатуры. */
public final class Commands {
    public static boolean openMenuNextTick;

    private Commands() {}

    private static void info(String msg) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.sendMessage(new LiteralText("§d[Nova]§r " + msg), false);
    }

    /** @return true если сообщение было командой и не должно уходить на сервер */
    public static boolean handle(String message) {
        if (!message.startsWith(".")) return false;
        String[] a = message.substring(1).trim().split("\\s+");
        switch (a[0].toLowerCase()) {
            case "menu":
                openMenuNextTick = true; // открываем в следующем тике: чат сам закрывает экран после отправки
                return true;
            case "t":
            case "toggle": {
                if (a.length < 2) { info("Использование: .t <модуль>"); return true; }
                Module m = ModuleManager.find(a[1]);
                if (m == null) { info("Нет такого модуля: " + a[1]); return true; }
                m.toggle();
                info(m.getName() + (m.isEnabled() ? " §aвключён" : " §cвыключен"));
                return true;
            }
            case "help":
                info(".menu - открыть меню, .t <модуль> - вкл/выкл модуль");
                return true;
            default:
                return false;
        }
    }
}

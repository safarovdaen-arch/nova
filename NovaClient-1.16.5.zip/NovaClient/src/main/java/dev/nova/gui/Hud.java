package dev.nova.gui;

import dev.nova.module.Module;
import dev.nova.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.util.math.MatrixStack;

import java.util.ArrayList;
import java.util.List;

public final class Hud {
    public static final int ACCENT = 0xFF9E6BFF;
    private static final int BG = 0xB0121217;
    private static final int WHITE = 0xFFFFFFFF;

    private Hud() {}

    public static void render(MatrixStack m) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;
        int fh = tr.fontHeight;

        // watermark
        String wm = "Nova Client | " + mc.getSession().getUsername();
        int w = tr.getWidth(wm);
        DrawableHelper.fill(m, 4, 4, 4 + w + 12, 4 + fh + 6, BG);
        DrawableHelper.fill(m, 4, 4, 6, 4 + fh + 6, ACCENT);
        tr.drawWithShadow(m, wm, 10, 7, WHITE);

        // список включённых модулей справа
        List<Module> enabled = new ArrayList<>();
        for (Module mod : ModuleManager.all()) if (mod.isEnabled()) enabled.add(mod);
        enabled.sort((x, y) -> tr.getWidth(y.getName()) - tr.getWidth(x.getName()));

        int sw = mc.getWindow().getScaledWidth();
        int y = 4;
        for (Module mod : enabled) {
            int tw = tr.getWidth(mod.getName());
            int x1 = sw - 4 - tw - 10;
            DrawableHelper.fill(m, x1, y, sw - 4, y + fh + 4, BG);
            DrawableHelper.fill(m, sw - 6, y, sw - 4, y + fh + 4, ACCENT);
            tr.drawWithShadow(m, mod.getName(), x1 + 4, y + 2, WHITE);
            y += fh + 5;
        }
    }
}

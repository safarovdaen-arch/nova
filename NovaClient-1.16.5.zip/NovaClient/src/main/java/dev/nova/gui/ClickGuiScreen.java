package dev.nova.gui;

import dev.nova.NovaClient;
import dev.nova.module.Category;
import dev.nova.module.Module;
import dev.nova.module.ModuleManager;
import dev.nova.setting.BoolSetting;
import dev.nova.setting.NumberSetting;
import dev.nova.setting.Setting;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ClickGuiScreen extends Screen {
    private static final int ACCENT = Hud.ACCENT;
    private static final int SIDE = 84, ROW = 22, PAD = 6;

    private static Category selected = Category.COMBAT;
    private static final Set<Module> expanded = new HashSet<>();
    private static float scroll;
    private static Module binding;

    private static class Hit {
        final int x1, y1, x2, y2;
        final boolean inList;
        final Runnable action;
        NumberSetting slider;
        int sx, sw;
        Hit(int x1, int y1, int x2, int y2, boolean inList, Runnable action) {
            this.x1 = x1; this.y1 = y1; this.x2 = x2; this.y2 = y2;
            this.inList = inList; this.action = action;
        }
        boolean contains(double mx, double my) { return mx >= x1 && mx < x2 && my >= y1 && my < y2; }
    }

    private final List<Hit> hits = new ArrayList<>();
    private int listTop, listBottom, listLeft, listRight;
    private float contentHeight;

    private Hit dragSlider;
    private boolean pressInList, moved;
    private Hit pressedHit;
    private double pressY, pressScroll;

    public ClickGuiScreen() { super(new LiteralText("Nova")); }

    @Override
    public boolean isPauseScreen() { return false; }

    // ---------------------------------------------------------------- render
    @Override
    public void render(MatrixStack m, int mx, int my, float delta) {
        hits.clear();
        int pw = Math.min(360, width - 8), ph = Math.min(230, height - 8);
        int px = (width - pw) / 2, py = (height - ph) / 2;

        fill(m, px, py, px + pw, py + ph, 0xF0121217);
        fill(m, px, py, px + SIDE, py + ph, 0xFF191920);
        textRenderer.drawWithShadow(m, "NOVA CLIENT", px + 10, py + 9, ACCENT);

        int y = py + 28;
        for (Category c : Category.values()) {
            boolean sel = c == selected;
            fill(m, px + 6, y, px + SIDE - 6, y + 22, sel ? 0xFF4A3B7A : 0xFF24242E);
            int tw = textRenderer.getWidth(c.label);
            textRenderer.drawWithShadow(m, c.label, px + (SIDE - tw) / 2f, y + 7, 0xFFFFFFFF);
            final Category cc = c;
            hits.add(new Hit(px + 6, y, px + SIDE - 6, y + 22, false, () -> { selected = cc; scroll = 0; }));
            y += 26;
        }

        listLeft = px + SIDE + PAD;
        listRight = px + pw - PAD;
        listTop = py + PAD;
        listBottom = py + ph - PAD;
        int lw = listRight - listLeft, lh = listBottom - listTop;

        // clamp scroll
        float maxScroll = Math.max(0, contentHeight - lh);
        scroll = Math.max(0, Math.min(maxScroll, scroll));

        double s = client.getWindow().getScaleFactor();
        int fbH = client.getWindow().getFramebufferHeight();
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor((int) (listLeft * s), (int) (fbH - listBottom * s), (int) (lw * s), (int) (lh * s));

        int cy = listTop - (int) scroll;
        int start = cy;
        for (Module mod : ModuleManager.byCategory(selected)) {
            cy = drawModule(m, mod, cy, lw);
        }
        contentHeight = cy - start;

        GL11.glDisable(GL11.GL_SCISSOR_TEST);
    }

    private int drawModule(MatrixStack m, Module mod, int y, int lw) {
        int x1 = listLeft, x2 = listRight;
        boolean on = mod.isEnabled();
        fill(m, x1, y, x2, y + ROW - 2, on ? 0xFF3A2F5E : 0xFF1E1E27);
        textRenderer.drawWithShadow(m, mod.getName(), x1 + 8, y + 7, on ? ACCENT : 0xFFFFFFFF);
        boolean open = expanded.contains(mod);
        textRenderer.drawWithShadow(m, open ? "v" : ">", x2 - 14, y + 7, 0xFFAAAAAA);

        hits.add(new Hit(x1, y, x2 - 26, y + ROW - 2, true, mod::toggle));
        hits.add(new Hit(x2 - 26, y, x2, y + ROW - 2, true, () -> {
            if (!expanded.remove(mod)) expanded.add(mod);
        }));
        y += ROW;

        if (!open) return y;

        // bind
        String keyName = mod.getKey() > 0
                ? InputUtil.fromKeyCode(mod.getKey(), 0).getLocalizedText().getString() : "None";
        y = drawRow(m, x1 + 8, x2, y, binding == mod ? "Press a key..." : "Bind: " + keyName, null,
                () -> binding = mod);

        for (Setting st : mod.getSettings()) {
            if (st instanceof BoolSetting) {
                BoolSetting b = (BoolSetting) st;
                y = drawRow(m, x1 + 8, x2, y, b.getName() + ": " + (b.get() ? "ON" : "OFF"),
                        b.get() ? ACCENT : null, b::toggle);
            } else if (st instanceof NumberSetting) {
                y = drawSlider(m, (NumberSetting) st, x1 + 8, x2, y);
            }
        }
        return y + 2;
    }

    private int drawRow(MatrixStack m, int x1, int x2, int y, String text, Integer color, Runnable action) {
        fill(m, x1, y, x2, y + 18, 0xFF16161D);
        textRenderer.drawWithShadow(m, text, x1 + 6, y + 5, color != null ? color : 0xFFDDDDDD);
        hits.add(new Hit(x1, y, x2, y + 18, true, action));
        return y + 20;
    }

    private int drawSlider(MatrixStack m, NumberSetting n, int x1, int x2, int y) {
        fill(m, x1, y, x2, y + 28, 0xFF16161D);
        textRenderer.drawWithShadow(m, n.getName() + ": " + String.format("%.2f", n.get()), x1 + 6, y + 4, 0xFFDDDDDD);
        int bx1 = x1 + 6, bx2 = x2 - 6, by = y + 18;
        fill(m, bx1, by, bx2, by + 4, 0xFF2A2A35);
        float t = (n.get() - n.getMin()) / (n.getMax() - n.getMin());
        int fx = bx1 + (int) ((bx2 - bx1) * t);
        fill(m, bx1, by, fx, by + 4, ACCENT);
        fill(m, fx - 2, by - 2, fx + 2, by + 6, 0xFFFFFFFF);
        Hit h = new Hit(x1, y, x2, y + 28, true, null);
        h.slider = n; h.sx = bx1; h.sw = bx2 - bx1;
        hits.add(h);
        return y + 30;
    }

    private Hit hitAt(double mx, double my) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!h.contains(mx, my)) continue;
            if (h.inList && (my < listTop || my > listBottom)) continue;
            return h;
        }
        return null;
    }

    private void updateSlider(Hit h, double mx) {
        float t = (float) Math.max(0, Math.min(1, (mx - h.sx) / h.sw));
        NumberSetting n = h.slider;
        float v = n.getMin() + t * (n.getMax() - n.getMin());
        n.set(Math.round(v * 100f) / 100f);
    }

    // ----------------------------------------------------------------- input
    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        Hit h = hitAt(mx, my);
        if (h != null && h.slider != null) {
            dragSlider = h;
            updateSlider(h, mx);
            return true;
        }
        if (h != null && !h.inList) { h.action.run(); return true; }

        boolean inListArea = mx >= listLeft && mx <= listRight && my >= listTop && my <= listBottom;
        if (inListArea) {
            pressInList = true;
            moved = false;
            pressedHit = h;
            pressY = my;
            pressScroll = scroll;
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragSlider != null) { updateSlider(dragSlider, mx); return true; }
        if (pressInList) {
            if (Math.abs(my - pressY) > 4) moved = true;
            if (moved) scroll = (float) (pressScroll - (my - pressY));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragSlider != null) { dragSlider = null; return true; }
        if (pressInList) {
            if (!moved && pressedHit != null && pressedHit.action != null) pressedHit.action.run();
            pressInList = false;
            pressedHit = null;
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double amount) {
        scroll -= amount * 15;
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (binding != null) {
            binding.setKey(keyCode == GLFW.GLFW_KEY_ESCAPE ? 0 : keyCode);
            binding = null;
            return true;
        }
        if (keyCode == NovaClient.MENU_KEY) { onClose(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() { binding = null; dragSlider = null; pressInList = false; }
}

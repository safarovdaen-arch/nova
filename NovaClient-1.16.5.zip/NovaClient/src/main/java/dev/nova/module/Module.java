package dev.nova.module;

import dev.nova.setting.Setting;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    private final String name;
    private final Category category;
    private final List<Setting> settings = new ArrayList<>();
    private boolean enabled;
    private int key;            // GLFW key code, 0 = no bind
    boolean keyWasDown;

    protected Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    protected static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    protected <T extends Setting> T add(T setting) { settings.add(setting); return setting; }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}
    /** Вызывается каждый тик, пока модуль включен (игрок и мир не null). */
    public void onTick() {}

    public String getName() { return name; }
    public Category getCategory() { return category; }
    public List<Setting> getSettings() { return settings; }
    public boolean isEnabled() { return enabled; }
    public int getKey() { return key; }
    public void setKey(int key) { this.key = key; }
}

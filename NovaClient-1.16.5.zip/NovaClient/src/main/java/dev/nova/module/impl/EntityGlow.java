package dev.nova.module.impl;

import dev.nova.module.Category;
import dev.nova.module.Module;
import dev.nova.setting.BoolSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

/** ESP через клиентское свечение сущностей (видно сквозь стены). */
public class EntityGlow extends Module {
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", true));

    public EntityGlow() { super("ESP", Category.RENDER); }

    @Override
    public void onTick() {
        for (Entity e : mc().world.getEntities()) {
            if (!(e instanceof LivingEntity) || e == mc().player) continue;
            boolean glow = e instanceof PlayerEntity ? players.get() : mobs.get();
            e.setGlowing(glow);
        }
    }

    @Override
    protected void onDisable() {
        if (mc().world == null) return;
        for (Entity e : mc().world.getEntities()) {
            if (e instanceof LivingEntity) e.setGlowing(false);
        }
    }
}

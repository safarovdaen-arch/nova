package dev.nova.module.impl;

import dev.nova.module.Category;
import dev.nova.module.Module;

public class FullBright extends Module {
    private double oldGamma = 1.0;

    public FullBright() { super("FullBright", Category.RENDER); }

    @Override
    protected void onEnable() { oldGamma = mc().options.gamma; }

    @Override
    public void onTick() { mc().options.gamma = 15.0; }

    @Override
    protected void onDisable() { mc().options.gamma = oldGamma; }
}

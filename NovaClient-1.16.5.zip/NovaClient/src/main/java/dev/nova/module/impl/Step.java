package dev.nova.module.impl;

import dev.nova.module.Category;
import dev.nova.module.Module;
import dev.nova.setting.NumberSetting;

public class Step extends Module {
    private final NumberSetting height = add(new NumberSetting("Height", 1.0f, 0.6f, 2.0f));

    public Step() { super("Step", Category.MOVEMENT); }

    @Override
    public void onTick() { mc().player.stepHeight = height.get(); }

    @Override
    protected void onDisable() {
        if (mc().player != null) mc().player.stepHeight = 0.6f;
    }
}

package dev.nova.module.impl;

import dev.nova.module.Category;
import dev.nova.module.Module;
import dev.nova.setting.BoolSetting;
import dev.nova.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;

public class KillAura extends Module {
    private final NumberSetting range = add(new NumberSetting("Range", 3.8f, 1f, 6f));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", true));
    private final BoolSetting rotate = add(new BoolSetting("Rotate", true));

    public KillAura() { super("KillAura", Category.COMBAT); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (p.getAttackCooldownProgress(0f) < 0.95f) return;

        Entity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : mc().world.getEntities()) {
            if (!(e instanceof LivingEntity) || e == p || !e.isAlive() || e.isSpectator()) continue;
            if (e instanceof ArmorStandEntity) continue;
            boolean isPlayer = e instanceof PlayerEntity;
            if (isPlayer ? !players.get() : !mobs.get()) continue;
            double d = p.distanceTo(e);
            if (d > range.get() || d >= bestDist) continue;
            best = e;
            bestDist = d;
        }
        if (best == null) return;

        if (rotate.get()) {
            double dx = best.getX() - p.getX();
            double dy = best.getBodyY(0.5) - p.getEyeY();
            double dz = best.getZ() - p.getZ();
            double h = Math.sqrt(dx * dx + dz * dz);
            p.yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
            p.pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
        }
        mc().interactionManager.attackEntity(p, best);
        p.swingHand(Hand.MAIN_HAND);
    }
}

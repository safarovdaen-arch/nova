package dev.nova.module.impl;

import dev.nova.module.Category;
import dev.nova.module.Module;
import dev.nova.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;

public class Fly extends Module {
    private final NumberSetting speed = add(new NumberSetting("Speed", 0.1f, 0.02f, 1.0f));

    public Fly() { super("Fly", Category.MOVEMENT); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        p.abilities.allowFlying = true;
        p.abilities.flying = true;
        p.abilities.setFlySpeed(speed.get());
    }

    @Override
    protected void onDisable() {
        ClientPlayerEntity p = mc().player;
        if (p == null) return;
        p.abilities.setFlySpeed(0.05f);
        if (!p.isCreative() && !p.isSpectator()) {
            p.abilities.allowFlying = false;
            p.abilities.flying = false;
        }
    }
}

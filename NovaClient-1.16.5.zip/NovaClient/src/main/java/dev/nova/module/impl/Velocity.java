package dev.nova.module.impl;

import dev.nova.module.Category;
import dev.nova.module.Module;

/** Логика в ClientPlayNetworkHandlerMixin: отменяет пакет отбрасывания. */
public class Velocity extends Module {
    public Velocity() { super("Velocity", Category.COMBAT); }
}

package dev.nova.module;

import dev.nova.module.impl.*;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();

    private ModuleManager() {}

    public static void init() {
        // Combat
        MODULES.add(new KillAura());
        MODULES.add(new Velocity());
        // Movement
        MODULES.add(new Sprint());
        MODULES.add(new Fly());
        MODULES.add(new Speed());
        MODULES.add(new Step());
        // Render
        MODULES.add(new FullBright());
        MODULES.add(new EntityGlow());
        // Player
        MODULES.add(new NoFall());
        MODULES.add(new AutoRespawn());
    }

    public static List<Module> all() { return MODULES; }

    public static List<Module> byCategory(Category category) {
        List<Module> list = new ArrayList<>();
        for (Module m : MODULES) if (m.getCategory() == category) list.add(m);
        return list;
    }

    public static Module find(String name) {
        for (Module m : MODULES) if (m.getName().equalsIgnoreCase(name)) return m;
        return null;
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T get(Class<T> type) {
        for (Module m : MODULES) if (type.isInstance(m)) return (T) m;
        return null;
    }

    public static void onTick(MinecraftClient mc) {
        long window = mc.getWindow().getHandle();
        for (Module m : MODULES) {
            if (m.getKey() > 0) {
                boolean down = GLFW.glfwGetKey(window, m.getKey()) == GLFW.GLFW_PRESS;
                if (down && !m.keyWasDown && mc.currentScreen == null) m.toggle();
                m.keyWasDown = down;
            }
            if (m.isEnabled()) m.onTick();
        }
    }
}

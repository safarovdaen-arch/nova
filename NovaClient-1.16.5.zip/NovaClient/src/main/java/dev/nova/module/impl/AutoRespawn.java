package dev.nova.module.impl;

import dev.nova.module.Category;
import dev.nova.module.Module;

public class AutoRespawn extends Module {
    public AutoRespawn() { super("AutoRespawn", Category.PLAYER); }

    @Override
    public void onTick() {
        if (mc().player.isDead()) mc().player.requestRespawn();
    }
}

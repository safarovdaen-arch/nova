package dev.nova.module.impl;

import dev.nova.module.Category;
import dev.nova.module.Module;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

public class NoFall extends Module {
    public NoFall() { super("NoFall", Category.PLAYER); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (p.fallDistance > 2.0f && !p.isFallFlying()) {
            p.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true));
        }
    }
}

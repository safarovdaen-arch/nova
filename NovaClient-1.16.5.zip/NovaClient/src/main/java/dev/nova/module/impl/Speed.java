package dev.nova.module.impl;

import dev.nova.module.Category;
import dev.nova.module.Module;
import dev.nova.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;

public class Speed extends Module {
    private final NumberSetting speed = add(new NumberSetting("Speed", 0.35f, 0.1f, 1.5f));

    public Speed() { super("Speed", Category.MOVEMENT); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        float f = p.input.movementForward;
        float s = p.input.movementSideways;
        if (f == 0 && s == 0) return;

        double len = Math.max(1.0, Math.sqrt(f * f + s * s));
        double yaw = Math.toRadians(p.yaw);
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        double dx = (s * cos - f * sin) / len * speed.get();
        double dz = (f * cos + s * sin) / len * speed.get();
        p.setVelocity(dx, p.getVelocity().y, dz);
    }
}

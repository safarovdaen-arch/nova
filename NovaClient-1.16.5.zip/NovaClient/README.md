# Nova Client (Fabric 1.16.5)

Меню рисуется самим Minecraft (без ImGui), поэтому работает и на ПК, и на Android (Pojav).

## Открыть меню
- клавиша Right Shift (в Pojav назначь её на экранную кнопку), или
- команда в чате: `.menu`
- `.t <модуль>` включает/выключает модуль, `.help` — справка.
В меню: тап по названию = вкл/выкл, `>` = настройки, свайп = прокрутка, ползунки тянутся.

## Получить готовый .jar без ПК (GitHub Actions)
1. Создай репозиторий на github.com.
2. Загрузи в него ВСЕ файлы проекта (Add file -> Upload files; папки лучше добавлять
   через "Режим для ПК" в браузере). Важна папка `.github/workflows`.
3. Вкладка Actions -> build -> Run workflow. Через ~3-5 минут внизу страницы
   запуска появится Artifact "NovaClient": в нём `nova-client-1.0.0.jar`.

## Сборка на ПК
JDK 17 + Gradle 7.3.3: `gradle build` -> `build/libs/nova-client-1.0.0.jar`
и `build/version/NovaClient.zip` (папка-версия с JSON).

## Установка в Pojav / любой лаунчер
Самый надёжный способ:
1. В лаунчере установи Fabric для 1.16.5 (Fabric Loader 0.14.x).
2. Положи `nova-client-1.0.0.jar` в папку `mods` этой версии/игры.
3. Запусти версию Fabric 1.16.5.
(Вариант с NovaClient.json из NovaClient.zip работает не во всех лаунчерах.)
